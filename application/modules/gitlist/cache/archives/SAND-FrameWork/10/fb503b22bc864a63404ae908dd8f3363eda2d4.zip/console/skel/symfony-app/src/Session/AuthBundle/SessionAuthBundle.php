<?php

namespace App\Session\AuthBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SessionAuthBundle extends Bundle
{
}
