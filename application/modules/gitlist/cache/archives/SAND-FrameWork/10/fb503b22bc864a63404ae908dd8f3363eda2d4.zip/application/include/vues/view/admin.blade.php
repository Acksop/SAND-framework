@extends('body')

@section('sidebar')
    @parent
@endsection

@section('content')
    <h1>Admin</h1>
    <br /><br /><br />

@endsection

