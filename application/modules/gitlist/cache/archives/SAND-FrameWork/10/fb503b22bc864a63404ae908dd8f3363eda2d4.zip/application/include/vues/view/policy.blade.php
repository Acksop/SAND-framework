@extends('body')

@section('sidebar')
    @parent
@endsection

@section('content')
    <div class="container">
        <h1>Politique Générale de Sécurité</h1>
        <br/>
        <br/>
        <p>1. Ce FrameWork est le fruit d'un travail personnel.</p><br/>
        <p>2. Certaines Parties du Framework sont le fruit d'un travail aboutit d'autres personnes</p><br/>
        <p>3. Ce Framework sera publié en open-source sous <a href="https://creativecommons.org/publicdomain/zero/1.0/deed.fr">licence CC Universal</a> ou <a href="https://creativecommons.org/licenses/by/4.0/deed.fr">licence CC-by-SA</a> suivant la disponibilité de l'auteur. </p>
        <br/>
        ...
        <br/>
        <br/>

        <p>Si cela ne vous plait pas veuillez envoyer un courriel à l'auteur et nous en parlerons le plus calmement possible.</p>
    </div>
@endsection