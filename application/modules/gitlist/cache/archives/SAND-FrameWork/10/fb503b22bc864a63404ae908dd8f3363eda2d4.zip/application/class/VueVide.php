<?php

namespace MVC\Classe;

class VueVide
{
    public $ecran;

    public function __construct()
    {
    }
}
