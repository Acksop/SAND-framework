<?php


define('DSN_BDD_DEFAULT', "mysql:host=localhost;dbname=default");
define('USER_BDD_DEFAULT', "user_default");
define('PASS_BDD_DEFAULT', "pass_default");

define('DSN_BDD1', "mysql:host=localhost;dbname=db1");
define('USER_BDD1', "user1");
define('PASS_BDD1', "pass1");

define('DSN_BDD2', "mysql:host=localhost;dbname=db2");
define('USER_BDD2', "user2");
define('PASS_BDD2', "pass2");