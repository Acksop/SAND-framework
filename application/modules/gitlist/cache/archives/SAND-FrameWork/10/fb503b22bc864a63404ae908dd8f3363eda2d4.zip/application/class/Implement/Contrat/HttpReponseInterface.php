<?php

namespace MVC\Classe\Implement\Contrat;

interface HttpReponseInterface
{
    public function put();

    public function delete();
}
