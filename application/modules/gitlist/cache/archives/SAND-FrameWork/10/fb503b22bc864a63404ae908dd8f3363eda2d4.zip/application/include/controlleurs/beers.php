<?php


use MVC\Classe\Logger;

$templateData = array("templating_a" => 'blade', "templating_b" => 'twig', "templating_c" => 'edge');
Logger::addLog('ok', 'Hello world');