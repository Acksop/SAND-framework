@extends('body')

@section('sidebar')
    @parent
@endsection

@section('content')
    <div class="container">
        <h1>Conditions Générale de l'application:</h1>
        <br/>
        <br/>
        <p>1. Cette application est en phase de test et n'est qu'un test.</p><br/>
        <p>2. Si cela est autre chose se référer au point 1.</p><br/>
        <p>3. Cette application peut permettre le développement du framework (SAND) dont la documentation sera écrite en MarkDown et publié par un moteur interne au framework.</p><br/>
    </div>
@endsection