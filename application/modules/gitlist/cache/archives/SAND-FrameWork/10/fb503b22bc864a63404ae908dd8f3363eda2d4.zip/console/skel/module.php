<?php
$app = new MVC\Classe\Modular($name, 'MODULE', $url_params);
$templateData = array('app' => $app);
